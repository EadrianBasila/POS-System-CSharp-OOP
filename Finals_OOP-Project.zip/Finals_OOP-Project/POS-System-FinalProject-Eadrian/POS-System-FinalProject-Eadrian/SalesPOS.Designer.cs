﻿namespace POSSystemOOPFinals
{
    partial class SalesPOS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SalesPOS));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.posTotalPrice = new System.Windows.Forms.TextBox();
            this.posPurchaseTB = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.ScreenTitle = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.posIcon = new System.Windows.Forms.PictureBox();
            this.inventoryIcon = new System.Windows.Forms.PictureBox();
            this.dashboardIcon = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.posTabs = new System.Windows.Forms.TabControl();
            this.tabSweets = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.posSweetsDV = new System.Windows.Forms.DataGridView();
            this.panel13 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.posSweets = new System.Windows.Forms.PictureBox();
            this.tabPastry = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.posButtonP = new System.Windows.Forms.Button();
            this.panel22 = new System.Windows.Forms.Panel();
            this.posPastries = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.posPastryDV = new System.Windows.Forms.DataGridView();
            this.tabMeats = new System.Windows.Forms.TabPage();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.posMeats = new System.Windows.Forms.PictureBox();
            this.posMeatsDV = new System.Windows.Forms.DataGridView();
            this.tabDrinks = new System.Windows.Forms.TabPage();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.button9 = new System.Windows.Forms.Button();
            this.panel18 = new System.Windows.Forms.Panel();
            this.posDrinks = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.posDrinksDV = new System.Windows.Forms.DataGridView();
            this.tabFruits = new System.Windows.Forms.TabPage();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.panel25 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.posFruits = new System.Windows.Forms.PictureBox();
            this.posFruitsDV = new System.Windows.Forms.DataGridView();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.productCost = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.productIdTB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.productStockTB = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.productPrice = new System.Windows.Forms.TextBox();
            this.productNameTB = new System.Windows.Forms.TextBox();
            this.button14 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.productPurchaseQuantity = new System.Windows.Forms.TextBox();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.productProfit = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardIcon)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.posTabs.SuspendLayout();
            this.tabSweets.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posSweetsDV)).BeginInit();
            this.panel13.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posSweets)).BeginInit();
            this.tabPastry.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posPastries)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.posPastryDV)).BeginInit();
            this.tabMeats.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posMeats)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.posMeatsDV)).BeginInit();
            this.tabDrinks.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posDrinks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.posDrinksDV)).BeginInit();
            this.tabFruits.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posFruits)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.posFruitsDV)).BeginInit();
            this.panel11.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel20.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.label4);
            this.panel9.Controls.Add(this.posTotalPrice);
            this.panel9.Controls.Add(this.posPurchaseTB);
            this.panel9.Controls.Add(this.button2);
            this.panel9.Controls.Add(this.label7);
            this.panel9.Controls.Add(this.pictureBox3);
            this.panel9.Controls.Add(this.pictureBox2);
            this.panel9.Location = new System.Drawing.Point(1314, 95);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(364, 745);
            this.panel9.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("dark forest", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label4.Location = new System.Drawing.Point(71, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(229, 37);
            this.label4.TabIndex = 8;
            this.label4.Text = "Purchase Summary";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // posTotalPrice
            // 
            this.posTotalPrice.BackColor = System.Drawing.Color.LimeGreen;
            this.posTotalPrice.Font = new System.Drawing.Font("Bebas Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posTotalPrice.ForeColor = System.Drawing.Color.White;
            this.posTotalPrice.Location = new System.Drawing.Point(86, 57);
            this.posTotalPrice.Name = "posTotalPrice";
            this.posTotalPrice.ReadOnly = true;
            this.posTotalPrice.Size = new System.Drawing.Size(260, 40);
            this.posTotalPrice.TabIndex = 30;
            this.posTotalPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // posPurchaseTB
            // 
            this.posPurchaseTB.BackColor = System.Drawing.Color.PaleGreen;
            this.posPurchaseTB.Font = new System.Drawing.Font("Bebas Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posPurchaseTB.ForeColor = System.Drawing.Color.Black;
            this.posPurchaseTB.Location = new System.Drawing.Point(14, 102);
            this.posPurchaseTB.Multiline = true;
            this.posPurchaseTB.Name = "posPurchaseTB";
            this.posPurchaseTB.ReadOnly = true;
            this.posPurchaseTB.Size = new System.Drawing.Size(333, 553);
            this.posPurchaseTB.TabIndex = 29;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Green;
            this.button2.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Bebas Neue", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(15, 661);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(258, 64);
            this.button2.TabIndex = 28;
            this.button2.Text = "CHECKOUT";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.LightGreen;
            this.label7.Font = new System.Drawing.Font("dark forest", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Green;
            this.label7.Location = new System.Drawing.Point(21, 636);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 37);
            this.label7.TabIndex = 27;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(6, 30);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(65, 68);
            this.pictureBox3.TabIndex = 21;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(279, 661);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(69, 64);
            this.pictureBox2.TabIndex = 17;
            this.pictureBox2.TabStop = false;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Location = new System.Drawing.Point(417, 12);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(10, 59);
            this.panel8.TabIndex = 9;
            this.panel8.Paint += new System.Windows.Forms.PaintEventHandler(this.panel8_Paint);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Bebas Neue", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.CalendarForeColor = System.Drawing.Color.Transparent;
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.Transparent;
            this.dateTimePicker1.CalendarTitleBackColor = System.Drawing.Color.Transparent;
            this.dateTimePicker1.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.dateTimePicker1.Cursor = System.Windows.Forms.Cursors.Default;
            this.dateTimePicker1.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(1308, 22);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(260, 31);
            this.dateTimePicker1.TabIndex = 2;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // ScreenTitle
            // 
            this.ScreenTitle.AutoSize = true;
            this.ScreenTitle.Font = new System.Drawing.Font("Bebas Neue", 37.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScreenTitle.ForeColor = System.Drawing.Color.White;
            this.ScreenTitle.Location = new System.Drawing.Point(2, -3);
            this.ScreenTitle.Name = "ScreenTitle";
            this.ScreenTitle.Size = new System.Drawing.Size(327, 76);
            this.ScreenTitle.TabIndex = 7;
            this.ScreenTitle.Text = "Point of Sales";
            this.ScreenTitle.Click += new System.EventHandler(this.ScreenTitle_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Location = new System.Drawing.Point(1576, 12);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(50, 50);
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(1638, 12);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(50, 50);
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.ScreenTitle);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1700, 74);
            this.panel1.TabIndex = 10;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // posIcon
            // 
            this.posIcon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("posIcon.BackgroundImage")));
            this.posIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.posIcon.Location = new System.Drawing.Point(17, 201);
            this.posIcon.Name = "posIcon";
            this.posIcon.Size = new System.Drawing.Size(101, 98);
            this.posIcon.TabIndex = 9;
            this.posIcon.TabStop = false;
            this.posIcon.Click += new System.EventHandler(this.posIcon_Click);
            // 
            // inventoryIcon
            // 
            this.inventoryIcon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("inventoryIcon.BackgroundImage")));
            this.inventoryIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.inventoryIcon.Location = new System.Drawing.Point(17, 323);
            this.inventoryIcon.Name = "inventoryIcon";
            this.inventoryIcon.Size = new System.Drawing.Size(101, 98);
            this.inventoryIcon.TabIndex = 11;
            this.inventoryIcon.TabStop = false;
            this.inventoryIcon.Click += new System.EventHandler(this.inventoryIcon_Click);
            // 
            // dashboardIcon
            // 
            this.dashboardIcon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("dashboardIcon.BackgroundImage")));
            this.dashboardIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dashboardIcon.Location = new System.Drawing.Point(17, 80);
            this.dashboardIcon.Name = "dashboardIcon";
            this.dashboardIcon.Size = new System.Drawing.Size(101, 98);
            this.dashboardIcon.TabIndex = 12;
            this.dashboardIcon.TabStop = false;
            this.dashboardIcon.Click += new System.EventHandler(this.dashboardIcon_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Red;
            this.panel5.Location = new System.Drawing.Point(122, 200);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(11, 99);
            this.panel5.TabIndex = 13;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.dashboardIcon);
            this.panel3.Controls.Add(this.inventoryIcon);
            this.panel3.Controls.Add(this.posIcon);
            this.panel3.Location = new System.Drawing.Point(0, 74);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(140, 786);
            this.panel3.TabIndex = 15;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(17, 664);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(101, 98);
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // posTabs
            // 
            this.posTabs.Controls.Add(this.tabSweets);
            this.posTabs.Controls.Add(this.tabPastry);
            this.posTabs.Controls.Add(this.tabMeats);
            this.posTabs.Controls.Add(this.tabDrinks);
            this.posTabs.Controls.Add(this.tabFruits);
            this.posTabs.Font = new System.Drawing.Font("Bebas Neue", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posTabs.Location = new System.Drawing.Point(163, 133);
            this.posTabs.Name = "posTabs";
            this.posTabs.SelectedIndex = 0;
            this.posTabs.Size = new System.Drawing.Size(934, 707);
            this.posTabs.TabIndex = 37;
            this.posTabs.Selected += new System.Windows.Forms.TabControlEventHandler(this.posTabs_Selected);
            // 
            // tabSweets
            // 
            this.tabSweets.BackColor = System.Drawing.Color.White;
            this.tabSweets.Controls.Add(this.panel4);
            this.tabSweets.Controls.Add(this.posSweetsDV);
            this.tabSweets.Controls.Add(this.panel13);
            this.tabSweets.Controls.Add(this.panel2);
            this.tabSweets.Font = new System.Drawing.Font("Bebas Neue", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabSweets.ForeColor = System.Drawing.Color.Black;
            this.tabSweets.Location = new System.Drawing.Point(4, 45);
            this.tabSweets.Name = "tabSweets";
            this.tabSweets.Padding = new System.Windows.Forms.Padding(3);
            this.tabSweets.Size = new System.Drawing.Size(926, 658);
            this.tabSweets.TabIndex = 0;
            this.tabSweets.Text = "Sweets";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkOrange;
            this.panel4.Location = new System.Drawing.Point(499, 23);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(410, 77);
            this.panel4.TabIndex = 62;
            // 
            // posSweetsDV
            // 
            this.posSweetsDV.AllowUserToAddRows = false;
            this.posSweetsDV.AllowUserToDeleteRows = false;
            this.posSweetsDV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.posSweetsDV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Bebas Neue", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.posSweetsDV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.posSweetsDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Bebas Neue", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.posSweetsDV.DefaultCellStyle = dataGridViewCellStyle9;
            this.posSweetsDV.Location = new System.Drawing.Point(20, 106);
            this.posSweetsDV.Name = "posSweetsDV";
            this.posSweetsDV.ReadOnly = true;
            this.posSweetsDV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Bebas Neue", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posSweetsDV.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.posSweetsDV.RowTemplate.Height = 48;
            this.posSweetsDV.RowTemplate.ReadOnly = true;
            this.posSweetsDV.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.posSweetsDV.Size = new System.Drawing.Size(889, 534);
            this.posSweetsDV.TabIndex = 59;
            this.posSweetsDV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.posSweetsDV_CellClick);
            this.posSweetsDV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.posSweetsDV_CellContentClick);
            this.posSweetsDV.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.posSweetsDV_DataBindingComplete);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.Orange;
            this.panel13.Controls.Add(this.button3);
            this.panel13.Location = new System.Drawing.Point(332, 23);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(167, 77);
            this.panel13.TabIndex = 56;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(9, 13);
            this.button3.Margin = new System.Windows.Forms.Padding(0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(148, 51);
            this.button3.TabIndex = 61;
            this.button3.Text = "Load Products";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.posSweets);
            this.panel2.Location = new System.Drawing.Point(20, 23);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(318, 77);
            this.panel2.TabIndex = 39;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.DodgerBlue;
            this.label11.Font = new System.Drawing.Font("dark forest", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(79, 4);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(150, 55);
            this.label11.TabIndex = 40;
            this.label11.Text = "SWEETS";
            // 
            // posSweets
            // 
            this.posSweets.BackColor = System.Drawing.Color.DodgerBlue;
            this.posSweets.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("posSweets.BackgroundImage")));
            this.posSweets.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.posSweets.Location = new System.Drawing.Point(3, 4);
            this.posSweets.Name = "posSweets";
            this.posSweets.Size = new System.Drawing.Size(70, 70);
            this.posSweets.TabIndex = 39;
            this.posSweets.TabStop = false;
            // 
            // tabPastry
            // 
            this.tabPastry.Controls.Add(this.panel7);
            this.tabPastry.Controls.Add(this.panel10);
            this.tabPastry.Controls.Add(this.panel22);
            this.tabPastry.Controls.Add(this.panel6);
            this.tabPastry.Controls.Add(this.posPastryDV);
            this.tabPastry.Location = new System.Drawing.Point(4, 45);
            this.tabPastry.Name = "tabPastry";
            this.tabPastry.Padding = new System.Windows.Forms.Padding(3);
            this.tabPastry.Size = new System.Drawing.Size(926, 658);
            this.tabPastry.TabIndex = 1;
            this.tabPastry.Text = "Pastry";
            this.tabPastry.UseVisualStyleBackColor = true;
            this.tabPastry.Click += new System.EventHandler(this.tabPastry_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DarkOrange;
            this.panel7.Location = new System.Drawing.Point(499, 20);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(410, 77);
            this.panel7.TabIndex = 66;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Orange;
            this.panel10.Controls.Add(this.posButtonP);
            this.panel10.Location = new System.Drawing.Point(332, 20);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(167, 77);
            this.panel10.TabIndex = 65;
            // 
            // posButtonP
            // 
            this.posButtonP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.posButtonP.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posButtonP.ForeColor = System.Drawing.Color.White;
            this.posButtonP.Location = new System.Drawing.Point(9, 14);
            this.posButtonP.Margin = new System.Windows.Forms.Padding(0);
            this.posButtonP.Name = "posButtonP";
            this.posButtonP.Size = new System.Drawing.Size(148, 51);
            this.posButtonP.TabIndex = 60;
            this.posButtonP.Text = "Load Products";
            this.posButtonP.UseVisualStyleBackColor = true;
            this.posButtonP.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel22.Controls.Add(this.posPastries);
            this.panel22.Controls.Add(this.label12);
            this.panel22.Location = new System.Drawing.Point(20, 20);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(318, 77);
            this.panel22.TabIndex = 64;
            // 
            // posPastries
            // 
            this.posPastries.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("posPastries.BackgroundImage")));
            this.posPastries.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.posPastries.Location = new System.Drawing.Point(5, 3);
            this.posPastries.Name = "posPastries";
            this.posPastries.Size = new System.Drawing.Size(70, 70);
            this.posPastries.TabIndex = 41;
            this.posPastries.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.DodgerBlue;
            this.label12.Font = new System.Drawing.Font("dark forest", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(81, 4);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(149, 55);
            this.label12.TabIndex = 40;
            this.label12.Text = "PASTRY";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkOrange;
            this.panel6.Location = new System.Drawing.Point(427, 42);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(0, 0);
            this.panel6.TabIndex = 63;
            // 
            // posPastryDV
            // 
            this.posPastryDV.AllowUserToAddRows = false;
            this.posPastryDV.AllowUserToDeleteRows = false;
            this.posPastryDV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.posPastryDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.posPastryDV.Location = new System.Drawing.Point(20, 103);
            this.posPastryDV.Name = "posPastryDV";
            this.posPastryDV.ReadOnly = true;
            this.posPastryDV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Bebas Neue", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posPastryDV.RowsDefaultCellStyle = dataGridViewCellStyle11;
            this.posPastryDV.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Bebas Neue", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posPastryDV.RowTemplate.Height = 48;
            this.posPastryDV.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.posPastryDV.Size = new System.Drawing.Size(889, 537);
            this.posPastryDV.TabIndex = 58;
            this.posPastryDV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.posPastryDV_CellClick);
            this.posPastryDV.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.posPastryDV_DataBindingComplete);
            // 
            // tabMeats
            // 
            this.tabMeats.Controls.Add(this.panel12);
            this.tabMeats.Controls.Add(this.panel14);
            this.tabMeats.Controls.Add(this.panel16);
            this.tabMeats.Controls.Add(this.posMeatsDV);
            this.tabMeats.Location = new System.Drawing.Point(4, 45);
            this.tabMeats.Name = "tabMeats";
            this.tabMeats.Size = new System.Drawing.Size(926, 658);
            this.tabMeats.TabIndex = 2;
            this.tabMeats.Text = "Meats";
            this.tabMeats.UseVisualStyleBackColor = true;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.DarkOrange;
            this.panel12.Location = new System.Drawing.Point(500, 20);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(410, 77);
            this.panel12.TabIndex = 69;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.Orange;
            this.panel14.Controls.Add(this.button8);
            this.panel14.Location = new System.Drawing.Point(333, 20);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(167, 77);
            this.panel14.TabIndex = 68;
            this.panel14.Paint += new System.Windows.Forms.PaintEventHandler(this.panel14_Paint);
            // 
            // button8
            // 
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(10, 15);
            this.button8.Margin = new System.Windows.Forms.Padding(0);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(148, 51);
            this.button8.TabIndex = 61;
            this.button8.Text = "Load Products";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel16.Controls.Add(this.label13);
            this.panel16.Controls.Add(this.posMeats);
            this.panel16.Location = new System.Drawing.Point(22, 20);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(318, 77);
            this.panel16.TabIndex = 67;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.DodgerBlue;
            this.label13.Font = new System.Drawing.Font("dark forest", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(79, 5);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(130, 55);
            this.label13.TabIndex = 40;
            this.label13.Text = "MEATS";
            // 
            // posMeats
            // 
            this.posMeats.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("posMeats.BackgroundImage")));
            this.posMeats.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.posMeats.Location = new System.Drawing.Point(3, 3);
            this.posMeats.Name = "posMeats";
            this.posMeats.Size = new System.Drawing.Size(70, 70);
            this.posMeats.TabIndex = 41;
            this.posMeats.TabStop = false;
            this.posMeats.Click += new System.EventHandler(this.posMeats_Click);
            // 
            // posMeatsDV
            // 
            this.posMeatsDV.AllowUserToAddRows = false;
            this.posMeatsDV.AllowUserToDeleteRows = false;
            this.posMeatsDV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.posMeatsDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.posMeatsDV.Location = new System.Drawing.Point(22, 103);
            this.posMeatsDV.Name = "posMeatsDV";
            this.posMeatsDV.ReadOnly = true;
            this.posMeatsDV.RowHeadersWidth = 51;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Bebas Neue", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posMeatsDV.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.posMeatsDV.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Bebas Neue", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posMeatsDV.RowTemplate.Height = 48;
            this.posMeatsDV.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.posMeatsDV.Size = new System.Drawing.Size(889, 537);
            this.posMeatsDV.TabIndex = 59;
            this.posMeatsDV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.posMeatsDV_CellClick_1);
            this.posMeatsDV.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.posMeatsDV_DataBindingComplete);
            // 
            // tabDrinks
            // 
            this.tabDrinks.Controls.Add(this.panel15);
            this.tabDrinks.Controls.Add(this.panel17);
            this.tabDrinks.Controls.Add(this.panel18);
            this.tabDrinks.Controls.Add(this.posDrinksDV);
            this.tabDrinks.Location = new System.Drawing.Point(4, 45);
            this.tabDrinks.Name = "tabDrinks";
            this.tabDrinks.Size = new System.Drawing.Size(926, 658);
            this.tabDrinks.TabIndex = 3;
            this.tabDrinks.Text = "Drinks";
            this.tabDrinks.UseVisualStyleBackColor = true;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.DarkOrange;
            this.panel15.Location = new System.Drawing.Point(497, 23);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(410, 77);
            this.panel15.TabIndex = 69;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.Orange;
            this.panel17.Controls.Add(this.button9);
            this.panel17.Location = new System.Drawing.Point(330, 23);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(167, 77);
            this.panel17.TabIndex = 68;
            // 
            // button9
            // 
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(10, 14);
            this.button9.Margin = new System.Windows.Forms.Padding(0);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(148, 51);
            this.button9.TabIndex = 61;
            this.button9.Text = "Load Products";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel18.Controls.Add(this.posDrinks);
            this.panel18.Controls.Add(this.label14);
            this.panel18.Location = new System.Drawing.Point(18, 23);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(319, 77);
            this.panel18.TabIndex = 67;
            // 
            // posDrinks
            // 
            this.posDrinks.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("posDrinks.BackgroundImage")));
            this.posDrinks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.posDrinks.Location = new System.Drawing.Point(4, 4);
            this.posDrinks.Name = "posDrinks";
            this.posDrinks.Size = new System.Drawing.Size(70, 70);
            this.posDrinks.TabIndex = 43;
            this.posDrinks.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.DodgerBlue;
            this.label14.Font = new System.Drawing.Font("dark forest", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(80, 4);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(137, 55);
            this.label14.TabIndex = 42;
            this.label14.Text = "DRINKS";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // posDrinksDV
            // 
            this.posDrinksDV.AllowUserToAddRows = false;
            this.posDrinksDV.AllowUserToDeleteRows = false;
            this.posDrinksDV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.posDrinksDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.posDrinksDV.Location = new System.Drawing.Point(18, 106);
            this.posDrinksDV.Name = "posDrinksDV";
            this.posDrinksDV.ReadOnly = true;
            this.posDrinksDV.RowHeadersWidth = 51;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Bebas Neue", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posDrinksDV.RowsDefaultCellStyle = dataGridViewCellStyle13;
            this.posDrinksDV.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Bebas Neue", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posDrinksDV.RowTemplate.Height = 48;
            this.posDrinksDV.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.posDrinksDV.Size = new System.Drawing.Size(889, 536);
            this.posDrinksDV.TabIndex = 60;
            this.posDrinksDV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.posDrinksDV_CellClick);
            this.posDrinksDV.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.posDrinksDV_DataBindingComplete);
            // 
            // tabFruits
            // 
            this.tabFruits.Controls.Add(this.panel23);
            this.tabFruits.Controls.Add(this.panel24);
            this.tabFruits.Controls.Add(this.panel25);
            this.tabFruits.Controls.Add(this.posFruitsDV);
            this.tabFruits.Location = new System.Drawing.Point(4, 45);
            this.tabFruits.Name = "tabFruits";
            this.tabFruits.Size = new System.Drawing.Size(926, 658);
            this.tabFruits.TabIndex = 4;
            this.tabFruits.Text = "Fruits";
            this.tabFruits.UseVisualStyleBackColor = true;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.DarkOrange;
            this.panel23.Location = new System.Drawing.Point(498, 20);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(410, 77);
            this.panel23.TabIndex = 69;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.Orange;
            this.panel24.Controls.Add(this.button10);
            this.panel24.Location = new System.Drawing.Point(331, 20);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(167, 77);
            this.panel24.TabIndex = 68;
            // 
            // button10
            // 
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(10, 14);
            this.button10.Margin = new System.Windows.Forms.Padding(0);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(148, 51);
            this.button10.TabIndex = 61;
            this.button10.Text = "Load Products";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel25.Controls.Add(this.label15);
            this.panel25.Controls.Add(this.posFruits);
            this.panel25.Location = new System.Drawing.Point(20, 20);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(318, 77);
            this.panel25.TabIndex = 67;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.DodgerBlue;
            this.label15.Font = new System.Drawing.Font("dark forest", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(79, 4);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(198, 55);
            this.label15.TabIndex = 42;
            this.label15.Text = "FRUITS";
            // 
            // posFruits
            // 
            this.posFruits.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("posFruits.BackgroundImage")));
            this.posFruits.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.posFruits.Location = new System.Drawing.Point(3, 3);
            this.posFruits.Name = "posFruits";
            this.posFruits.Size = new System.Drawing.Size(70, 70);
            this.posFruits.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.posFruits.TabIndex = 41;
            this.posFruits.TabStop = false;
            // 
            // posFruitsDV
            // 
            this.posFruitsDV.AllowUserToAddRows = false;
            this.posFruitsDV.AllowUserToDeleteRows = false;
            this.posFruitsDV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.posFruitsDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.posFruitsDV.Location = new System.Drawing.Point(19, 103);
            this.posFruitsDV.Name = "posFruitsDV";
            this.posFruitsDV.ReadOnly = true;
            this.posFruitsDV.RowHeadersWidth = 51;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Bebas Neue", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posFruitsDV.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.posFruitsDV.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Bebas Neue", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posFruitsDV.RowTemplate.Height = 48;
            this.posFruitsDV.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.posFruitsDV.Size = new System.Drawing.Size(889, 537);
            this.posFruitsDV.TabIndex = 61;
            this.posFruitsDV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.posFruitsDV_CellClick);
            this.posFruitsDV.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.posFruitsDV_DataBindingComplete);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Orange;
            this.panel11.Controls.Add(this.label3);
            this.panel11.Controls.Add(this.productCost);
            this.panel11.Controls.Add(this.label2);
            this.panel11.Controls.Add(this.productIdTB);
            this.panel11.Controls.Add(this.label1);
            this.panel11.Controls.Add(this.productStockTB);
            this.panel11.Controls.Add(this.label18);
            this.panel11.Controls.Add(this.label17);
            this.panel11.Controls.Add(this.productPrice);
            this.panel11.Controls.Add(this.productNameTB);
            this.panel11.Location = new System.Drawing.Point(9, 86);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(190, 335);
            this.panel11.TabIndex = 58;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(6, 154);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 24);
            this.label3.TabIndex = 71;
            this.label3.Text = "Cost:";
            // 
            // productCost
            // 
            this.productCost.BackColor = System.Drawing.Color.White;
            this.productCost.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.productCost.Font = new System.Drawing.Font("Bebas Neue", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productCost.Location = new System.Drawing.Point(10, 185);
            this.productCost.Name = "productCost";
            this.productCost.ReadOnly = true;
            this.productCost.Size = new System.Drawing.Size(80, 40);
            this.productCost.TabIndex = 70;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(6, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 24);
            this.label2.TabIndex = 69;
            this.label2.Text = "Product ID:";
            // 
            // productIdTB
            // 
            this.productIdTB.BackColor = System.Drawing.Color.White;
            this.productIdTB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.productIdTB.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productIdTB.Location = new System.Drawing.Point(10, 57);
            this.productIdTB.Name = "productIdTB";
            this.productIdTB.ReadOnly = true;
            this.productIdTB.Size = new System.Drawing.Size(170, 28);
            this.productIdTB.TabIndex = 65;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 234);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 24);
            this.label1.TabIndex = 68;
            this.label1.Text = "Current Stock:";
            // 
            // productStockTB
            // 
            this.productStockTB.BackColor = System.Drawing.Color.White;
            this.productStockTB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.productStockTB.Font = new System.Drawing.Font("Bebas Neue", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productStockTB.Location = new System.Drawing.Point(11, 266);
            this.productStockTB.Name = "productStockTB";
            this.productStockTB.ReadOnly = true;
            this.productStockTB.Size = new System.Drawing.Size(170, 40);
            this.productStockTB.TabIndex = 67;
            this.productStockTB.TextChanged += new System.EventHandler(this.productStockTB_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(96, 154);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(54, 24);
            this.label18.TabIndex = 66;
            this.label18.Text = "Retail:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(6, 90);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(107, 24);
            this.label17.TabIndex = 66;
            this.label17.Text = "Product Name:";
            // 
            // productPrice
            // 
            this.productPrice.BackColor = System.Drawing.Color.White;
            this.productPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.productPrice.Font = new System.Drawing.Font("Bebas Neue", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productPrice.Location = new System.Drawing.Point(100, 185);
            this.productPrice.Name = "productPrice";
            this.productPrice.ReadOnly = true;
            this.productPrice.Size = new System.Drawing.Size(80, 40);
            this.productPrice.TabIndex = 64;
            // 
            // productNameTB
            // 
            this.productNameTB.BackColor = System.Drawing.Color.White;
            this.productNameTB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.productNameTB.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productNameTB.Location = new System.Drawing.Point(10, 120);
            this.productNameTB.Name = "productNameTB";
            this.productNameTB.ReadOnly = true;
            this.productNameTB.Size = new System.Drawing.Size(170, 28);
            this.productNameTB.TabIndex = 64;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.OrangeRed;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Bebas Neue", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(32, 166);
            this.button14.Margin = new System.Windows.Forms.Padding(0);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(131, 50);
            this.button14.TabIndex = 69;
            this.button14.Text = "Reset:";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click_1);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(9, 16);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 24);
            this.label16.TabIndex = 67;
            this.label16.Text = "Quantity:";
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.LimeGreen;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Bebas Neue", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.White;
            this.button15.Location = new System.Drawing.Point(32, 111);
            this.button15.Margin = new System.Windows.Forms.Padding(0);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(131, 50);
            this.button15.TabIndex = 68;
            this.button15.Text = "ADD:";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click_1);
            // 
            // productPurchaseQuantity
            // 
            this.productPurchaseQuantity.BackColor = System.Drawing.Color.White;
            this.productPurchaseQuantity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.productPurchaseQuantity.Font = new System.Drawing.Font("Bebas Neue", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productPurchaseQuantity.Location = new System.Drawing.Point(10, 49);
            this.productPurchaseQuantity.Name = "productPurchaseQuantity";
            this.productPurchaseQuantity.Size = new System.Drawing.Size(170, 45);
            this.productPurchaseQuantity.TabIndex = 65;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.White;
            this.panel19.Controls.Add(this.panel21);
            this.panel19.Controls.Add(this.panel20);
            this.panel19.Controls.Add(this.panel11);
            this.panel19.Location = new System.Drawing.Point(1102, 178);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(206, 662);
            this.panel19.TabIndex = 38;
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel21.Controls.Add(this.productProfit);
            this.panel21.Controls.Add(this.label5);
            this.panel21.Location = new System.Drawing.Point(9, 10);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(190, 80);
            this.panel21.TabIndex = 71;
            // 
            // productProfit
            // 
            this.productProfit.BackColor = System.Drawing.Color.White;
            this.productProfit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.productProfit.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productProfit.ForeColor = System.Drawing.Color.DodgerBlue;
            this.productProfit.Location = new System.Drawing.Point(10, 37);
            this.productProfit.Name = "productProfit";
            this.productProfit.ReadOnly = true;
            this.productProfit.Size = new System.Drawing.Size(170, 28);
            this.productProfit.TabIndex = 71;
            this.productProfit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(6, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 24);
            this.label5.TabIndex = 70;
            this.label5.Text = "Profit:";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.DarkOrange;
            this.panel20.Controls.Add(this.label16);
            this.panel20.Controls.Add(this.button14);
            this.panel20.Controls.Add(this.button15);
            this.panel20.Controls.Add(this.productPurchaseQuantity);
            this.panel20.Location = new System.Drawing.Point(9, 421);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(190, 227);
            this.panel20.TabIndex = 70;
            // 
            // SalesPOS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(1700, 860);
            this.Controls.Add(this.panel19);
            this.Controls.Add(this.posTabs);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SalesPOS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.SalesPOS_Load);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardIcon)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.posTabs.ResumeLayout(false);
            this.tabSweets.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.posSweetsDV)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posSweets)).EndInit();
            this.tabPastry.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posPastries)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.posPastryDV)).EndInit();
            this.tabMeats.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posMeats)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.posMeatsDV)).EndInit();
            this.tabDrinks.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posDrinks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.posDrinksDV)).EndInit();
            this.tabFruits.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.posFruits)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.posFruitsDV)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label ScreenTitle;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox posIcon;
        private System.Windows.Forms.PictureBox inventoryIcon;
        private System.Windows.Forms.PictureBox dashboardIcon;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabControl posTabs;
        private System.Windows.Forms.TabPage tabSweets;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox posSweets;
        private System.Windows.Forms.TabPage tabPastry;
        private System.Windows.Forms.PictureBox posPastries;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabPage tabMeats;
        private System.Windows.Forms.PictureBox posMeats;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TabPage tabDrinks;
        private System.Windows.Forms.PictureBox posDrinks;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TabPage tabFruits;
        private System.Windows.Forms.PictureBox posFruits;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DataGridView posPastryDV;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button posButtonP;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.DataGridView posSweetsDV;
        private System.Windows.Forms.DataGridView posMeatsDV;
        private System.Windows.Forms.DataGridView posDrinksDV;
        private System.Windows.Forms.DataGridView posFruitsDV;
        private System.Windows.Forms.TextBox posPurchaseTB;
        private System.Windows.Forms.TextBox posTotalPrice;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox productNameTB;
        private System.Windows.Forms.TextBox productPurchaseQuantity;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox productStockTB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox productIdTB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox productCost;
        private System.Windows.Forms.TextBox productPrice;
        private System.Windows.Forms.TextBox productProfit;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}