﻿namespace POSSystemOOPFinals
{
    public class netProfit
    {
        public int Year { get; set; }
        public int Month { get; set; }
        public double Value { get; set; }
    }
}
