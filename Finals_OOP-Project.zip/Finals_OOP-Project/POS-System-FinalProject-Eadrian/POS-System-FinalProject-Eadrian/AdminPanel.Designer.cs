﻿namespace POS_System_FinalProject_Eadrian
{
    partial class AdminPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminPanel));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.ScreenTitle = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.peepsCategory = new System.Windows.Forms.ListBox();
            this.label9 = new System.Windows.Forms.Label();
            this.apdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.employeeSalaryTB = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.employeePasswordTB = new System.Windows.Forms.TextBox();
            this.employeeUsernameTB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.employeeNameTB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.employeeIdTB = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dashboardIcon = new System.Windows.Forms.PictureBox();
            this.inventoryIcon = new System.Windows.Forms.PictureBox();
            this.posIcon = new System.Windows.Forms.PictureBox();
            this.adminTabs = new System.Windows.Forms.TabControl();
            this.tabAdmin = new System.Windows.Forms.TabPage();
            this.adminAdminDV = new System.Windows.Forms.DataGridView();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.loadAdmin = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.posSweets = new System.Windows.Forms.PictureBox();
            this.tabEmployee = new System.Windows.Forms.TabPage();
            this.adminEmployeeDV = new System.Windows.Forms.DataGridView();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.loadEmployee = new System.Windows.Forms.Button();
            this.panel15 = new System.Windows.Forms.Panel();
            this.posMeats = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tabSales = new System.Windows.Forms.TabPage();
            this.adminSalesDV = new System.Windows.Forms.DataGridView();
            this.panel12 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.loadSales = new System.Windows.Forms.Button();
            this.panel16 = new System.Windows.Forms.Panel();
            this.tabWorkshift = new System.Windows.Forms.TabPage();
            this.adminShiftsDV = new System.Windows.Forms.DataGridView();
            this.panel19 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.loadShifts = new System.Windows.Forms.Button();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.exportExcel = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel9.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.posIcon)).BeginInit();
            this.adminTabs.SuspendLayout();
            this.tabAdmin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adminAdminDV)).BeginInit();
            this.panel13.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posSweets)).BeginInit();
            this.tabEmployee.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adminEmployeeDV)).BeginInit();
            this.panel18.SuspendLayout();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posMeats)).BeginInit();
            this.tabSales.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adminSalesDV)).BeginInit();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel14.SuspendLayout();
            this.tabWorkshift.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adminShiftsDV)).BeginInit();
            this.panel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel20.SuspendLayout();
            this.panel23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.exportExcel)).BeginInit();
            this.panel22.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.ScreenTitle);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1700, 74);
            this.panel1.TabIndex = 12;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Location = new System.Drawing.Point(428, 9);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(10, 59);
            this.panel8.TabIndex = 9;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Bebas Neue", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.CalendarForeColor = System.Drawing.Color.Transparent;
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.Transparent;
            this.dateTimePicker1.CalendarTitleBackColor = System.Drawing.Color.Transparent;
            this.dateTimePicker1.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.dateTimePicker1.Cursor = System.Windows.Forms.Cursors.Default;
            this.dateTimePicker1.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(1308, 22);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(260, 31);
            this.dateTimePicker1.TabIndex = 2;
            // 
            // ScreenTitle
            // 
            this.ScreenTitle.AutoSize = true;
            this.ScreenTitle.Font = new System.Drawing.Font("Bebas Neue", 37.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScreenTitle.ForeColor = System.Drawing.Color.White;
            this.ScreenTitle.Location = new System.Drawing.Point(2, -3);
            this.ScreenTitle.Name = "ScreenTitle";
            this.ScreenTitle.Size = new System.Drawing.Size(335, 76);
            this.ScreenTitle.TabIndex = 7;
            this.ScreenTitle.Text = "Administrator";
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Location = new System.Drawing.Point(1576, 12);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(50, 50);
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(1638, 12);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(50, 50);
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.label16);
            this.panel9.Controls.Add(this.textBox1);
            this.panel9.Controls.Add(this.button4);
            this.panel9.Location = new System.Drawing.Point(1220, 672);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(459, 146);
            this.panel9.TabIndex = 44;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label16.Location = new System.Drawing.Point(11, 16);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(210, 24);
            this.label16.TabIndex = 5;
            this.label16.Text = "Employee Specific Indentifier:";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox1.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(15, 46);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(408, 28);
            this.textBox1.TabIndex = 4;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Red;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Bebas Neue", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(162, 84);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(143, 50);
            this.button4.TabIndex = 3;
            this.button4.Text = "DELETE";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel7.Controls.Add(this.label10);
            this.panel7.Location = new System.Drawing.Point(1220, 627);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(459, 47);
            this.panel7.TabIndex = 45;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.DodgerBlue;
            this.label10.Font = new System.Drawing.Font("Bebas Neue", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(9, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(217, 36);
            this.label10.TabIndex = 42;
            this.label10.Text = "Remove an Employee";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.pictureBox4);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.peepsCategory);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.apdateTimePicker);
            this.panel6.Controls.Add(this.employeeSalaryTB);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.employeePasswordTB);
            this.panel6.Controls.Add(this.employeeUsernameTB);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.employeeNameTB);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.button2);
            this.panel6.Controls.Add(this.button1);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.employeeIdTB);
            this.panel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel6.Location = new System.Drawing.Point(1220, 205);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(459, 422);
            this.panel6.TabIndex = 43;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(400, 9);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(30, 30);
            this.pictureBox4.TabIndex = 19;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label4.Location = new System.Drawing.Point(228, 199);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 24);
            this.label4.TabIndex = 18;
            this.label4.Text = "Category:";
            // 
            // peepsCategory
            // 
            this.peepsCategory.BackColor = System.Drawing.Color.Gainsboro;
            this.peepsCategory.Font = new System.Drawing.Font("Bebas Neue", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.peepsCategory.FormattingEnabled = true;
            this.peepsCategory.ItemHeight = 21;
            this.peepsCategory.Items.AddRange(new object[] {
            "Administrator",
            "Employee"});
            this.peepsCategory.Location = new System.Drawing.Point(232, 231);
            this.peepsCategory.Name = "peepsCategory";
            this.peepsCategory.Size = new System.Drawing.Size(198, 25);
            this.peepsCategory.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.DodgerBlue;
            this.label9.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(17, 284);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 24);
            this.label9.TabIndex = 16;
            this.label9.Text = "Date Hired:";
            // 
            // apdateTimePicker
            // 
            this.apdateTimePicker.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apdateTimePicker.Location = new System.Drawing.Point(185, 283);
            this.apdateTimePicker.Name = "apdateTimePicker";
            this.apdateTimePicker.Size = new System.Drawing.Size(245, 28);
            this.apdateTimePicker.TabIndex = 15;
            // 
            // employeeSalaryTB
            // 
            this.employeeSalaryTB.BackColor = System.Drawing.Color.Gainsboro;
            this.employeeSalaryTB.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeSalaryTB.Location = new System.Drawing.Point(15, 228);
            this.employeeSalaryTB.Name = "employeeSalaryTB";
            this.employeeSalaryTB.Size = new System.Drawing.Size(211, 28);
            this.employeeSalaryTB.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label7.Location = new System.Drawing.Point(11, 200);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(125, 24);
            this.label7.TabIndex = 11;
            this.label7.Text = "Employee Salary:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label6.Location = new System.Drawing.Point(228, 137);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 24);
            this.label6.TabIndex = 10;
            this.label6.Text = "Login Password:";
            // 
            // employeePasswordTB
            // 
            this.employeePasswordTB.BackColor = System.Drawing.Color.Gainsboro;
            this.employeePasswordTB.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeePasswordTB.Location = new System.Drawing.Point(232, 166);
            this.employeePasswordTB.Name = "employeePasswordTB";
            this.employeePasswordTB.Size = new System.Drawing.Size(198, 28);
            this.employeePasswordTB.TabIndex = 9;
            // 
            // employeeUsernameTB
            // 
            this.employeeUsernameTB.BackColor = System.Drawing.Color.Gainsboro;
            this.employeeUsernameTB.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeUsernameTB.Location = new System.Drawing.Point(15, 166);
            this.employeeUsernameTB.Name = "employeeUsernameTB";
            this.employeeUsernameTB.Size = new System.Drawing.Size(211, 28);
            this.employeeUsernameTB.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label5.Location = new System.Drawing.Point(11, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 24);
            this.label5.TabIndex = 7;
            this.label5.Text = "Login Username:";
            // 
            // employeeNameTB
            // 
            this.employeeNameTB.BackColor = System.Drawing.Color.Gainsboro;
            this.employeeNameTB.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeNameTB.Location = new System.Drawing.Point(15, 102);
            this.employeeNameTB.Name = "employeeNameTB";
            this.employeeNameTB.Size = new System.Drawing.Size(415, 28);
            this.employeeNameTB.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label3.Location = new System.Drawing.Point(11, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "Employee Name:";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Orange;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Bebas Neue", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(229, 345);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(143, 50);
            this.button2.TabIndex = 2;
            this.button2.Text = "UPDATE";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LimeGreen;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Bebas Neue", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(68, 345);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(143, 50);
            this.button1.TabIndex = 2;
            this.button1.Text = "ADD";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label2.Location = new System.Drawing.Point(11, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(210, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Employee Specific Indentifier:";
            // 
            // employeeIdTB
            // 
            this.employeeIdTB.BackColor = System.Drawing.Color.Gainsboro;
            this.employeeIdTB.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeIdTB.Location = new System.Drawing.Point(15, 42);
            this.employeeIdTB.Name = "employeeIdTB";
            this.employeeIdTB.ReadOnly = true;
            this.employeeIdTB.Size = new System.Drawing.Size(415, 28);
            this.employeeIdTB.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel4.Controls.Add(this.label1);
            this.panel4.Location = new System.Drawing.Point(1220, 161);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(459, 47);
            this.panel4.TabIndex = 42;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DodgerBlue;
            this.label1.Font = new System.Drawing.Font("Bebas Neue", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(283, 36);
            this.label1.TabIndex = 41;
            this.label1.Text = "ADD OR UPDATE AN EMPLOYEE";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.dashboardIcon);
            this.panel3.Controls.Add(this.inventoryIcon);
            this.panel3.Controls.Add(this.posIcon);
            this.panel3.Location = new System.Drawing.Point(0, 74);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(140, 786);
            this.panel3.TabIndex = 46;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(17, 649);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(101, 98);
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Red;
            this.panel5.Location = new System.Drawing.Point(124, 649);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(11, 99);
            this.panel5.TabIndex = 13;
            // 
            // dashboardIcon
            // 
            this.dashboardIcon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("dashboardIcon.BackgroundImage")));
            this.dashboardIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dashboardIcon.Location = new System.Drawing.Point(17, 80);
            this.dashboardIcon.Name = "dashboardIcon";
            this.dashboardIcon.Size = new System.Drawing.Size(101, 98);
            this.dashboardIcon.TabIndex = 12;
            this.dashboardIcon.TabStop = false;
            this.dashboardIcon.Click += new System.EventHandler(this.dashboardIcon_Click);
            // 
            // inventoryIcon
            // 
            this.inventoryIcon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("inventoryIcon.BackgroundImage")));
            this.inventoryIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.inventoryIcon.Location = new System.Drawing.Point(17, 323);
            this.inventoryIcon.Name = "inventoryIcon";
            this.inventoryIcon.Size = new System.Drawing.Size(101, 98);
            this.inventoryIcon.TabIndex = 11;
            this.inventoryIcon.TabStop = false;
            this.inventoryIcon.Click += new System.EventHandler(this.inventoryIcon_Click);
            // 
            // posIcon
            // 
            this.posIcon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("posIcon.BackgroundImage")));
            this.posIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.posIcon.Location = new System.Drawing.Point(17, 201);
            this.posIcon.Name = "posIcon";
            this.posIcon.Size = new System.Drawing.Size(101, 98);
            this.posIcon.TabIndex = 9;
            this.posIcon.TabStop = false;
            this.posIcon.Click += new System.EventHandler(this.posIcon_Click);
            // 
            // adminTabs
            // 
            this.adminTabs.Controls.Add(this.tabAdmin);
            this.adminTabs.Controls.Add(this.tabEmployee);
            this.adminTabs.Controls.Add(this.tabSales);
            this.adminTabs.Controls.Add(this.tabWorkshift);
            this.adminTabs.Font = new System.Drawing.Font("Bebas Neue", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminTabs.Location = new System.Drawing.Point(166, 116);
            this.adminTabs.Name = "adminTabs";
            this.adminTabs.SelectedIndex = 0;
            this.adminTabs.Size = new System.Drawing.Size(1037, 707);
            this.adminTabs.TabIndex = 47;
            // 
            // tabAdmin
            // 
            this.tabAdmin.BackColor = System.Drawing.Color.White;
            this.tabAdmin.Controls.Add(this.adminAdminDV);
            this.tabAdmin.Controls.Add(this.panel11);
            this.tabAdmin.Controls.Add(this.panel13);
            this.tabAdmin.Controls.Add(this.panel10);
            this.tabAdmin.Font = new System.Drawing.Font("Bebas Neue", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabAdmin.ForeColor = System.Drawing.Color.Black;
            this.tabAdmin.Location = new System.Drawing.Point(4, 45);
            this.tabAdmin.Name = "tabAdmin";
            this.tabAdmin.Padding = new System.Windows.Forms.Padding(3);
            this.tabAdmin.Size = new System.Drawing.Size(1029, 658);
            this.tabAdmin.TabIndex = 0;
            this.tabAdmin.Text = "Administrator";
            // 
            // adminAdminDV
            // 
            this.adminAdminDV.AllowUserToAddRows = false;
            this.adminAdminDV.AllowUserToDeleteRows = false;
            this.adminAdminDV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.adminAdminDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.adminAdminDV.Location = new System.Drawing.Point(19, 20);
            this.adminAdminDV.Name = "adminAdminDV";
            this.adminAdminDV.ReadOnly = true;
            this.adminAdminDV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Bebas Neue", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.DodgerBlue;
            this.adminAdminDV.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.adminAdminDV.RowTemplate.Height = 24;
            this.adminAdminDV.Size = new System.Drawing.Size(804, 619);
            this.adminAdminDV.TabIndex = 59;
            this.adminAdminDV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.adminAdminDV_CellClick);
            this.adminAdminDV.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.adminAdminDV_DataBindingComplete);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.DarkOrange;
            this.panel11.Location = new System.Drawing.Point(835, 351);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(178, 289);
            this.panel11.TabIndex = 57;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.Orange;
            this.panel13.Controls.Add(this.loadAdmin);
            this.panel13.Location = new System.Drawing.Point(835, 229);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(178, 122);
            this.panel13.TabIndex = 56;
            // 
            // loadAdmin
            // 
            this.loadAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loadAdmin.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadAdmin.ForeColor = System.Drawing.Color.White;
            this.loadAdmin.Location = new System.Drawing.Point(15, 36);
            this.loadAdmin.Margin = new System.Windows.Forms.Padding(0);
            this.loadAdmin.Name = "loadAdmin";
            this.loadAdmin.Size = new System.Drawing.Size(148, 51);
            this.loadAdmin.TabIndex = 61;
            this.loadAdmin.Text = "Load People";
            this.loadAdmin.UseVisualStyleBackColor = true;
            this.loadAdmin.Click += new System.EventHandler(this.loadAdmin_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel10.Controls.Add(this.label11);
            this.panel10.Controls.Add(this.posSweets);
            this.panel10.Location = new System.Drawing.Point(835, 20);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(178, 209);
            this.panel10.TabIndex = 39;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.DodgerBlue;
            this.label11.Font = new System.Drawing.Font("dark forest", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(15, 155);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 49);
            this.label11.TabIndex = 40;
            this.label11.Text = "Admin";
            // 
            // posSweets
            // 
            this.posSweets.BackColor = System.Drawing.Color.DodgerBlue;
            this.posSweets.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("posSweets.BackgroundImage")));
            this.posSweets.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.posSweets.Location = new System.Drawing.Point(24, 23);
            this.posSweets.Name = "posSweets";
            this.posSweets.Size = new System.Drawing.Size(130, 130);
            this.posSweets.TabIndex = 39;
            this.posSweets.TabStop = false;
            // 
            // tabEmployee
            // 
            this.tabEmployee.Controls.Add(this.adminEmployeeDV);
            this.tabEmployee.Controls.Add(this.panel17);
            this.tabEmployee.Controls.Add(this.panel18);
            this.tabEmployee.Controls.Add(this.panel15);
            this.tabEmployee.Location = new System.Drawing.Point(4, 45);
            this.tabEmployee.Name = "tabEmployee";
            this.tabEmployee.Size = new System.Drawing.Size(1029, 658);
            this.tabEmployee.TabIndex = 2;
            this.tabEmployee.Text = "Employee";
            this.tabEmployee.UseVisualStyleBackColor = true;
            // 
            // adminEmployeeDV
            // 
            this.adminEmployeeDV.AllowUserToAddRows = false;
            this.adminEmployeeDV.AllowUserToDeleteRows = false;
            this.adminEmployeeDV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.adminEmployeeDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.adminEmployeeDV.Location = new System.Drawing.Point(19, 20);
            this.adminEmployeeDV.Name = "adminEmployeeDV";
            this.adminEmployeeDV.ReadOnly = true;
            this.adminEmployeeDV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.adminEmployeeDV.RowTemplate.Height = 24;
            this.adminEmployeeDV.Size = new System.Drawing.Size(804, 619);
            this.adminEmployeeDV.TabIndex = 59;
            this.adminEmployeeDV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.adminEmployeeDV_CellClick);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.DarkOrange;
            this.panel17.Location = new System.Drawing.Point(833, 350);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(178, 289);
            this.panel17.TabIndex = 57;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.Orange;
            this.panel18.Controls.Add(this.loadEmployee);
            this.panel18.Location = new System.Drawing.Point(833, 229);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(178, 122);
            this.panel18.TabIndex = 56;
            // 
            // loadEmployee
            // 
            this.loadEmployee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loadEmployee.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadEmployee.ForeColor = System.Drawing.Color.White;
            this.loadEmployee.Location = new System.Drawing.Point(15, 36);
            this.loadEmployee.Margin = new System.Windows.Forms.Padding(0);
            this.loadEmployee.Name = "loadEmployee";
            this.loadEmployee.Size = new System.Drawing.Size(148, 51);
            this.loadEmployee.TabIndex = 61;
            this.loadEmployee.Text = "Load People";
            this.loadEmployee.UseVisualStyleBackColor = true;
            this.loadEmployee.Click += new System.EventHandler(this.loadEmployee_Click);
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel15.Controls.Add(this.posMeats);
            this.panel15.Controls.Add(this.label13);
            this.panel15.Location = new System.Drawing.Point(833, 20);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(178, 209);
            this.panel15.TabIndex = 48;
            // 
            // posMeats
            // 
            this.posMeats.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("posMeats.BackgroundImage")));
            this.posMeats.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.posMeats.Location = new System.Drawing.Point(25, 28);
            this.posMeats.Name = "posMeats";
            this.posMeats.Size = new System.Drawing.Size(130, 130);
            this.posMeats.TabIndex = 41;
            this.posMeats.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.DodgerBlue;
            this.label13.Font = new System.Drawing.Font("dark forest", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(-4, 154);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(147, 43);
            this.label13.TabIndex = 40;
            this.label13.Text = "Employee";
            // 
            // tabSales
            // 
            this.tabSales.Controls.Add(this.adminSalesDV);
            this.tabSales.Controls.Add(this.panel12);
            this.tabSales.Controls.Add(this.panel14);
            this.tabSales.Controls.Add(this.panel16);
            this.tabSales.Location = new System.Drawing.Point(4, 45);
            this.tabSales.Name = "tabSales";
            this.tabSales.Padding = new System.Windows.Forms.Padding(3);
            this.tabSales.Size = new System.Drawing.Size(1029, 658);
            this.tabSales.TabIndex = 3;
            this.tabSales.Text = "Sales";
            this.tabSales.UseVisualStyleBackColor = true;
            // 
            // adminSalesDV
            // 
            this.adminSalesDV.AllowUserToAddRows = false;
            this.adminSalesDV.AllowUserToDeleteRows = false;
            this.adminSalesDV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.adminSalesDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.adminSalesDV.Location = new System.Drawing.Point(18, 20);
            this.adminSalesDV.Name = "adminSalesDV";
            this.adminSalesDV.ReadOnly = true;
            this.adminSalesDV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.adminSalesDV.RowTemplate.Height = 24;
            this.adminSalesDV.Size = new System.Drawing.Size(804, 619);
            this.adminSalesDV.TabIndex = 63;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel12.Controls.Add(this.pictureBox2);
            this.panel12.Controls.Add(this.label8);
            this.panel12.Location = new System.Drawing.Point(832, 20);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(178, 209);
            this.panel12.TabIndex = 60;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(25, 28);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(130, 130);
            this.pictureBox2.TabIndex = 41;
            this.pictureBox2.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.DodgerBlue;
            this.label8.Font = new System.Drawing.Font("dark forest", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(17, 161);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 43);
            this.label8.TabIndex = 40;
            this.label8.Text = "Sales";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.Orange;
            this.panel14.Controls.Add(this.loadSales);
            this.panel14.Location = new System.Drawing.Point(832, 229);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(178, 122);
            this.panel14.TabIndex = 61;
            // 
            // loadSales
            // 
            this.loadSales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loadSales.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadSales.ForeColor = System.Drawing.Color.White;
            this.loadSales.Location = new System.Drawing.Point(15, 36);
            this.loadSales.Margin = new System.Windows.Forms.Padding(0);
            this.loadSales.Name = "loadSales";
            this.loadSales.Size = new System.Drawing.Size(148, 51);
            this.loadSales.TabIndex = 61;
            this.loadSales.Text = "Load Sales";
            this.loadSales.UseVisualStyleBackColor = true;
            this.loadSales.Click += new System.EventHandler(this.loadSales_Click);
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.DarkOrange;
            this.panel16.Location = new System.Drawing.Point(832, 350);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(178, 289);
            this.panel16.TabIndex = 62;
            // 
            // tabWorkshift
            // 
            this.tabWorkshift.Controls.Add(this.adminShiftsDV);
            this.tabWorkshift.Controls.Add(this.panel19);
            this.tabWorkshift.Controls.Add(this.panel20);
            this.tabWorkshift.Controls.Add(this.panel21);
            this.tabWorkshift.Location = new System.Drawing.Point(4, 45);
            this.tabWorkshift.Name = "tabWorkshift";
            this.tabWorkshift.Padding = new System.Windows.Forms.Padding(3);
            this.tabWorkshift.Size = new System.Drawing.Size(1029, 658);
            this.tabWorkshift.TabIndex = 4;
            this.tabWorkshift.Text = "Work Shifts";
            this.tabWorkshift.UseVisualStyleBackColor = true;
            // 
            // adminShiftsDV
            // 
            this.adminShiftsDV.AllowUserToAddRows = false;
            this.adminShiftsDV.AllowUserToDeleteRows = false;
            this.adminShiftsDV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.adminShiftsDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.adminShiftsDV.Location = new System.Drawing.Point(18, 20);
            this.adminShiftsDV.Name = "adminShiftsDV";
            this.adminShiftsDV.ReadOnly = true;
            this.adminShiftsDV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.adminShiftsDV.RowTemplate.Height = 24;
            this.adminShiftsDV.Size = new System.Drawing.Size(804, 619);
            this.adminShiftsDV.TabIndex = 63;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel19.Controls.Add(this.pictureBox3);
            this.panel19.Controls.Add(this.label12);
            this.panel19.Location = new System.Drawing.Point(832, 20);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(178, 209);
            this.panel19.TabIndex = 60;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(25, 28);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(130, 130);
            this.pictureBox3.TabIndex = 41;
            this.pictureBox3.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.DodgerBlue;
            this.label12.Font = new System.Drawing.Font("dark forest", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(17, 161);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(103, 43);
            this.label12.TabIndex = 40;
            this.label12.Text = "Shifts";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.Orange;
            this.panel20.Controls.Add(this.loadShifts);
            this.panel20.Location = new System.Drawing.Point(832, 229);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(178, 122);
            this.panel20.TabIndex = 61;
            // 
            // loadShifts
            // 
            this.loadShifts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loadShifts.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadShifts.ForeColor = System.Drawing.Color.White;
            this.loadShifts.Location = new System.Drawing.Point(15, 36);
            this.loadShifts.Margin = new System.Windows.Forms.Padding(0);
            this.loadShifts.Name = "loadShifts";
            this.loadShifts.Size = new System.Drawing.Size(148, 51);
            this.loadShifts.TabIndex = 61;
            this.loadShifts.Text = "Load Records";
            this.loadShifts.UseVisualStyleBackColor = true;
            this.loadShifts.Click += new System.EventHandler(this.loadShifts_Click);
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.DarkOrange;
            this.panel21.Location = new System.Drawing.Point(832, 350);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(178, 289);
            this.panel21.TabIndex = 62;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.White;
            this.panel23.Controls.Add(this.label19);
            this.panel23.Controls.Add(this.exportExcel);
            this.panel23.Controls.Add(this.label17);
            this.panel23.Location = new System.Drawing.Point(1352, 89);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(327, 66);
            this.panel23.TabIndex = 48;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Green;
            this.label19.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(13, 35);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(128, 20);
            this.label19.TabIndex = 14;
            this.label19.Text = "Into Microsoft Excel";
            // 
            // exportExcel
            // 
            this.exportExcel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("exportExcel.BackgroundImage")));
            this.exportExcel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.exportExcel.Location = new System.Drawing.Point(256, 6);
            this.exportExcel.Name = "exportExcel";
            this.exportExcel.Size = new System.Drawing.Size(64, 57);
            this.exportExcel.TabIndex = 13;
            this.exportExcel.TabStop = false;
            this.exportExcel.Click += new System.EventHandler(this.exportExcel_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.DodgerBlue;
            this.label17.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(13, 15);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(180, 20);
            this.label17.TabIndex = 5;
            this.label17.Text = "Export Workforce Collection";
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel22.Controls.Add(this.label18);
            this.panel22.Location = new System.Drawing.Point(1220, 89);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(140, 66);
            this.panel22.TabIndex = 49;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.DodgerBlue;
            this.label18.Font = new System.Drawing.Font("Bebas Neue", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(2, 12);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(108, 45);
            this.label18.TabIndex = 5;
            this.label18.Text = "EXPORT";
            // 
            // AdminPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1700, 860);
            this.Controls.Add(this.panel23);
            this.Controls.Add(this.panel22);
            this.Controls.Add(this.adminTabs);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdminPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminPanel";
            this.Load += new System.EventHandler(this.AdminPanel_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.posIcon)).EndInit();
            this.adminTabs.ResumeLayout(false);
            this.tabAdmin.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.adminAdminDV)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posSweets)).EndInit();
            this.tabEmployee.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.adminEmployeeDV)).EndInit();
            this.panel18.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posMeats)).EndInit();
            this.tabSales.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.adminSalesDV)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel14.ResumeLayout(false);
            this.tabWorkshift.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.adminShiftsDV)).EndInit();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel20.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.exportExcel)).EndInit();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label ScreenTitle;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker apdateTimePicker;
        private System.Windows.Forms.TextBox employeeSalaryTB;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox employeePasswordTB;
        private System.Windows.Forms.TextBox employeeUsernameTB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox employeeNameTB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox employeeIdTB;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox dashboardIcon;
        private System.Windows.Forms.PictureBox inventoryIcon;
        private System.Windows.Forms.PictureBox posIcon;
        private System.Windows.Forms.TabControl adminTabs;
        private System.Windows.Forms.TabPage tabAdmin;
        private System.Windows.Forms.DataGridView adminAdminDV;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button loadAdmin;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox posSweets;
        private System.Windows.Forms.TabPage tabEmployee;
        private System.Windows.Forms.DataGridView adminEmployeeDV;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Button loadEmployee;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.PictureBox posMeats;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox peepsCategory;
        private System.Windows.Forms.TabPage tabSales;
        private System.Windows.Forms.DataGridView adminSalesDV;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Button loadSales;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TabPage tabWorkshift;
        private System.Windows.Forms.DataGridView adminShiftsDV;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Button loadShifts;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox exportExcel;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}