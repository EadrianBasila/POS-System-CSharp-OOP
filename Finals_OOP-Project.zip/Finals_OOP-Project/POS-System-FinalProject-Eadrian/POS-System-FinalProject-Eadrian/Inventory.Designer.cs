﻿namespace POS_System_FinalProject_Eadrian
{
    partial class Inventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inventory));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.ScreenTitle = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dashboardIcon = new System.Windows.Forms.PictureBox();
            this.inventoryIcon = new System.Windows.Forms.PictureBox();
            this.posIcon = new System.Windows.Forms.PictureBox();
            this.invTabs = new System.Windows.Forms.TabControl();
            this.tabSweets = new System.Windows.Forms.TabPage();
            this.invSweetsDV = new System.Windows.Forms.DataGridView();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.invButtonS = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.posSweets = new System.Windows.Forms.PictureBox();
            this.tabPastry = new System.Windows.Forms.TabPage();
            this.invPastryDV = new System.Windows.Forms.DataGridView();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.invButtonP = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.posPastries = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tabMeats = new System.Windows.Forms.TabPage();
            this.invMeatsDV = new System.Windows.Forms.DataGridView();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.invButtonM = new System.Windows.Forms.Button();
            this.panel15 = new System.Windows.Forms.Panel();
            this.posMeats = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tabDrinks = new System.Windows.Forms.TabPage();
            this.invDrinksDV = new System.Windows.Forms.DataGridView();
            this.panel24 = new System.Windows.Forms.Panel();
            this.posDrinks = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.invButtonD = new System.Windows.Forms.Button();
            this.tabFruits = new System.Windows.Forms.TabPage();
            this.invFruitsDV = new System.Windows.Forms.DataGridView();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.invButtonF = new System.Windows.Forms.Button();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.posFruits = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.productdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.productlistCategory = new System.Windows.Forms.ListBox();
            this.productSupplierTB = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.productRetailTB = new System.Windows.Forms.TextBox();
            this.productCostTB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.productQuantityTB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.productNameTB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.productIdTB = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.exportExcel = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.posIcon)).BeginInit();
            this.invTabs.SuspendLayout();
            this.tabSweets.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invSweetsDV)).BeginInit();
            this.panel13.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posSweets)).BeginInit();
            this.tabPastry.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invPastryDV)).BeginInit();
            this.panel16.SuspendLayout();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posPastries)).BeginInit();
            this.tabMeats.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invMeatsDV)).BeginInit();
            this.panel18.SuspendLayout();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posMeats)).BeginInit();
            this.tabDrinks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invDrinksDV)).BeginInit();
            this.panel24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posDrinks)).BeginInit();
            this.panel26.SuspendLayout();
            this.tabFruits.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invFruitsDV)).BeginInit();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posFruits)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel7.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.exportExcel)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.ScreenTitle);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1700, 74);
            this.panel1.TabIndex = 11;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Location = new System.Drawing.Point(306, 11);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(10, 59);
            this.panel8.TabIndex = 9;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Bebas Neue", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.CalendarForeColor = System.Drawing.Color.Transparent;
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.Transparent;
            this.dateTimePicker1.CalendarTitleBackColor = System.Drawing.Color.Transparent;
            this.dateTimePicker1.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.dateTimePicker1.Cursor = System.Windows.Forms.Cursors.Default;
            this.dateTimePicker1.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(1308, 22);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(260, 31);
            this.dateTimePicker1.TabIndex = 2;
            // 
            // ScreenTitle
            // 
            this.ScreenTitle.AutoSize = true;
            this.ScreenTitle.Font = new System.Drawing.Font("Bebas Neue", 37.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScreenTitle.ForeColor = System.Drawing.Color.White;
            this.ScreenTitle.Location = new System.Drawing.Point(2, -3);
            this.ScreenTitle.Name = "ScreenTitle";
            this.ScreenTitle.Size = new System.Drawing.Size(243, 76);
            this.ScreenTitle.TabIndex = 7;
            this.ScreenTitle.Text = "Inventory";
            this.ScreenTitle.Click += new System.EventHandler(this.ScreenTitle_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Location = new System.Drawing.Point(1576, 12);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(50, 50);
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(1638, 12);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(50, 50);
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.dashboardIcon);
            this.panel3.Controls.Add(this.inventoryIcon);
            this.panel3.Controls.Add(this.posIcon);
            this.panel3.Location = new System.Drawing.Point(-1, 74);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(140, 786);
            this.panel3.TabIndex = 16;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(17, 659);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(101, 98);
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Red;
            this.panel5.Location = new System.Drawing.Point(122, 322);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(11, 99);
            this.panel5.TabIndex = 13;
            // 
            // dashboardIcon
            // 
            this.dashboardIcon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("dashboardIcon.BackgroundImage")));
            this.dashboardIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dashboardIcon.Location = new System.Drawing.Point(17, 80);
            this.dashboardIcon.Name = "dashboardIcon";
            this.dashboardIcon.Size = new System.Drawing.Size(101, 98);
            this.dashboardIcon.TabIndex = 12;
            this.dashboardIcon.TabStop = false;
            this.dashboardIcon.Click += new System.EventHandler(this.dashboardIcon_Click);
            // 
            // inventoryIcon
            // 
            this.inventoryIcon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("inventoryIcon.BackgroundImage")));
            this.inventoryIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.inventoryIcon.Location = new System.Drawing.Point(17, 323);
            this.inventoryIcon.Name = "inventoryIcon";
            this.inventoryIcon.Size = new System.Drawing.Size(101, 98);
            this.inventoryIcon.TabIndex = 11;
            this.inventoryIcon.TabStop = false;
            this.inventoryIcon.Click += new System.EventHandler(this.inventoryIcon_Click);
            // 
            // posIcon
            // 
            this.posIcon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("posIcon.BackgroundImage")));
            this.posIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.posIcon.Location = new System.Drawing.Point(17, 201);
            this.posIcon.Name = "posIcon";
            this.posIcon.Size = new System.Drawing.Size(101, 98);
            this.posIcon.TabIndex = 9;
            this.posIcon.TabStop = false;
            this.posIcon.Click += new System.EventHandler(this.posIcon_Click);
            // 
            // invTabs
            // 
            this.invTabs.Controls.Add(this.tabSweets);
            this.invTabs.Controls.Add(this.tabPastry);
            this.invTabs.Controls.Add(this.tabMeats);
            this.invTabs.Controls.Add(this.tabDrinks);
            this.invTabs.Controls.Add(this.tabFruits);
            this.invTabs.Font = new System.Drawing.Font("Bebas Neue", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invTabs.Location = new System.Drawing.Point(163, 124);
            this.invTabs.Name = "invTabs";
            this.invTabs.SelectedIndex = 0;
            this.invTabs.Size = new System.Drawing.Size(1037, 707);
            this.invTabs.TabIndex = 38;
            // 
            // tabSweets
            // 
            this.tabSweets.BackColor = System.Drawing.Color.White;
            this.tabSweets.Controls.Add(this.invSweetsDV);
            this.tabSweets.Controls.Add(this.panel11);
            this.tabSweets.Controls.Add(this.panel13);
            this.tabSweets.Controls.Add(this.panel2);
            this.tabSweets.Font = new System.Drawing.Font("Bebas Neue", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabSweets.ForeColor = System.Drawing.Color.Black;
            this.tabSweets.Location = new System.Drawing.Point(4, 45);
            this.tabSweets.Name = "tabSweets";
            this.tabSweets.Padding = new System.Windows.Forms.Padding(3);
            this.tabSweets.Size = new System.Drawing.Size(1029, 658);
            this.tabSweets.TabIndex = 0;
            this.tabSweets.Text = "Sweets";
            // 
            // invSweetsDV
            // 
            this.invSweetsDV.AllowUserToAddRows = false;
            this.invSweetsDV.AllowUserToDeleteRows = false;
            this.invSweetsDV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.invSweetsDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.invSweetsDV.Location = new System.Drawing.Point(19, 20);
            this.invSweetsDV.Name = "invSweetsDV";
            this.invSweetsDV.ReadOnly = true;
            this.invSweetsDV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Bebas Neue", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.DodgerBlue;
            this.invSweetsDV.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.invSweetsDV.RowTemplate.Height = 24;
            this.invSweetsDV.Size = new System.Drawing.Size(804, 619);
            this.invSweetsDV.TabIndex = 59;
            this.invSweetsDV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invSweetsDV_CellClick);
            this.invSweetsDV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invSweetsDV_CellContentClick);
            this.invSweetsDV.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.invSweetsDV_DataBindingComplete);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.DarkOrange;
            this.panel11.Location = new System.Drawing.Point(835, 351);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(178, 289);
            this.panel11.TabIndex = 57;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.Orange;
            this.panel13.Controls.Add(this.invButtonS);
            this.panel13.Location = new System.Drawing.Point(835, 229);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(178, 122);
            this.panel13.TabIndex = 56;
            // 
            // invButtonS
            // 
            this.invButtonS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.invButtonS.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invButtonS.ForeColor = System.Drawing.Color.White;
            this.invButtonS.Location = new System.Drawing.Point(15, 36);
            this.invButtonS.Margin = new System.Windows.Forms.Padding(0);
            this.invButtonS.Name = "invButtonS";
            this.invButtonS.Size = new System.Drawing.Size(148, 51);
            this.invButtonS.TabIndex = 61;
            this.invButtonS.Text = "Load Products";
            this.invButtonS.UseVisualStyleBackColor = true;
            this.invButtonS.Click += new System.EventHandler(this.invButtonS_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.posSweets);
            this.panel2.Location = new System.Drawing.Point(835, 20);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(178, 209);
            this.panel2.TabIndex = 39;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.DodgerBlue;
            this.label11.Font = new System.Drawing.Font("dark forest", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(5, 155);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(134, 49);
            this.label11.TabIndex = 40;
            this.label11.Text = "SWEETS";
            // 
            // posSweets
            // 
            this.posSweets.BackColor = System.Drawing.Color.DodgerBlue;
            this.posSweets.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("posSweets.BackgroundImage")));
            this.posSweets.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.posSweets.Location = new System.Drawing.Point(24, 23);
            this.posSweets.Name = "posSweets";
            this.posSweets.Size = new System.Drawing.Size(130, 130);
            this.posSweets.TabIndex = 39;
            this.posSweets.TabStop = false;
            // 
            // tabPastry
            // 
            this.tabPastry.Controls.Add(this.invPastryDV);
            this.tabPastry.Controls.Add(this.panel14);
            this.tabPastry.Controls.Add(this.panel16);
            this.tabPastry.Controls.Add(this.panel12);
            this.tabPastry.Location = new System.Drawing.Point(4, 45);
            this.tabPastry.Name = "tabPastry";
            this.tabPastry.Padding = new System.Windows.Forms.Padding(3);
            this.tabPastry.Size = new System.Drawing.Size(1029, 658);
            this.tabPastry.TabIndex = 1;
            this.tabPastry.Text = "Pastry";
            this.tabPastry.UseVisualStyleBackColor = true;
            // 
            // invPastryDV
            // 
            this.invPastryDV.AllowUserToAddRows = false;
            this.invPastryDV.AllowUserToDeleteRows = false;
            this.invPastryDV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.invPastryDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.invPastryDV.Location = new System.Drawing.Point(22, 20);
            this.invPastryDV.Name = "invPastryDV";
            this.invPastryDV.ReadOnly = true;
            this.invPastryDV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.invPastryDV.RowTemplate.Height = 24;
            this.invPastryDV.Size = new System.Drawing.Size(804, 619);
            this.invPastryDV.TabIndex = 59;
            this.invPastryDV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invPastryDV_CellClick);
            this.invPastryDV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invPastryDV_CellContentClick);
            this.invPastryDV.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.invPastryDV_DataBindingComplete);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.DarkOrange;
            this.panel14.Location = new System.Drawing.Point(836, 345);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(178, 294);
            this.panel14.TabIndex = 57;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.Orange;
            this.panel16.Controls.Add(this.invButtonP);
            this.panel16.Location = new System.Drawing.Point(836, 224);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(178, 122);
            this.panel16.TabIndex = 56;
            // 
            // invButtonP
            // 
            this.invButtonP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.invButtonP.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invButtonP.ForeColor = System.Drawing.Color.White;
            this.invButtonP.Location = new System.Drawing.Point(15, 36);
            this.invButtonP.Margin = new System.Windows.Forms.Padding(0);
            this.invButtonP.Name = "invButtonP";
            this.invButtonP.Size = new System.Drawing.Size(148, 51);
            this.invButtonP.TabIndex = 60;
            this.invButtonP.Text = "Load Products";
            this.invButtonP.UseVisualStyleBackColor = true;
            this.invButtonP.Click += new System.EventHandler(this.invButtonP_Click);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel12.Controls.Add(this.posPastries);
            this.panel12.Controls.Add(this.label12);
            this.panel12.Location = new System.Drawing.Point(836, 20);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(178, 204);
            this.panel12.TabIndex = 44;
            // 
            // posPastries
            // 
            this.posPastries.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("posPastries.BackgroundImage")));
            this.posPastries.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.posPastries.Location = new System.Drawing.Point(24, 22);
            this.posPastries.Name = "posPastries";
            this.posPastries.Size = new System.Drawing.Size(130, 130);
            this.posPastries.TabIndex = 41;
            this.posPastries.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.DodgerBlue;
            this.label12.Font = new System.Drawing.Font("dark forest", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(3, 154);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(131, 49);
            this.label12.TabIndex = 40;
            this.label12.Text = "PASTRY";
            // 
            // tabMeats
            // 
            this.tabMeats.Controls.Add(this.invMeatsDV);
            this.tabMeats.Controls.Add(this.panel17);
            this.tabMeats.Controls.Add(this.panel18);
            this.tabMeats.Controls.Add(this.panel15);
            this.tabMeats.Location = new System.Drawing.Point(4, 45);
            this.tabMeats.Name = "tabMeats";
            this.tabMeats.Size = new System.Drawing.Size(1029, 658);
            this.tabMeats.TabIndex = 2;
            this.tabMeats.Text = "Meats";
            this.tabMeats.UseVisualStyleBackColor = true;
            this.tabMeats.Click += new System.EventHandler(this.tabMeats_Click);
            // 
            // invMeatsDV
            // 
            this.invMeatsDV.AllowUserToAddRows = false;
            this.invMeatsDV.AllowUserToDeleteRows = false;
            this.invMeatsDV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.invMeatsDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.invMeatsDV.Location = new System.Drawing.Point(19, 20);
            this.invMeatsDV.Name = "invMeatsDV";
            this.invMeatsDV.ReadOnly = true;
            this.invMeatsDV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.invMeatsDV.RowTemplate.Height = 24;
            this.invMeatsDV.Size = new System.Drawing.Size(804, 619);
            this.invMeatsDV.TabIndex = 59;
            this.invMeatsDV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invMeatsDV_CellClick);
            this.invMeatsDV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invMeatsDV_CellContentClick);
            this.invMeatsDV.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.invMeatsDV_DataBindingComplete);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.DarkOrange;
            this.panel17.Location = new System.Drawing.Point(833, 350);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(178, 289);
            this.panel17.TabIndex = 57;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.Orange;
            this.panel18.Controls.Add(this.invButtonM);
            this.panel18.Location = new System.Drawing.Point(833, 229);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(178, 122);
            this.panel18.TabIndex = 56;
            // 
            // invButtonM
            // 
            this.invButtonM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.invButtonM.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invButtonM.ForeColor = System.Drawing.Color.White;
            this.invButtonM.Location = new System.Drawing.Point(15, 36);
            this.invButtonM.Margin = new System.Windows.Forms.Padding(0);
            this.invButtonM.Name = "invButtonM";
            this.invButtonM.Size = new System.Drawing.Size(148, 51);
            this.invButtonM.TabIndex = 61;
            this.invButtonM.Text = "Load Products";
            this.invButtonM.UseVisualStyleBackColor = true;
            this.invButtonM.Click += new System.EventHandler(this.invButtonM_Click);
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel15.Controls.Add(this.posMeats);
            this.panel15.Controls.Add(this.label13);
            this.panel15.Location = new System.Drawing.Point(833, 20);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(178, 209);
            this.panel15.TabIndex = 48;
            // 
            // posMeats
            // 
            this.posMeats.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("posMeats.BackgroundImage")));
            this.posMeats.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.posMeats.Location = new System.Drawing.Point(25, 28);
            this.posMeats.Name = "posMeats";
            this.posMeats.Size = new System.Drawing.Size(130, 130);
            this.posMeats.TabIndex = 41;
            this.posMeats.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.DodgerBlue;
            this.label13.Font = new System.Drawing.Font("dark forest", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(1, 154);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(130, 55);
            this.label13.TabIndex = 40;
            this.label13.Text = "MEATS";
            // 
            // tabDrinks
            // 
            this.tabDrinks.Controls.Add(this.invDrinksDV);
            this.tabDrinks.Controls.Add(this.panel24);
            this.tabDrinks.Controls.Add(this.panel25);
            this.tabDrinks.Controls.Add(this.panel26);
            this.tabDrinks.Location = new System.Drawing.Point(4, 45);
            this.tabDrinks.Name = "tabDrinks";
            this.tabDrinks.Size = new System.Drawing.Size(1029, 658);
            this.tabDrinks.TabIndex = 3;
            this.tabDrinks.Text = "Drinks";
            this.tabDrinks.UseVisualStyleBackColor = true;
            this.tabDrinks.Click += new System.EventHandler(this.tabDrinks_Click);
            // 
            // invDrinksDV
            // 
            this.invDrinksDV.AllowUserToAddRows = false;
            this.invDrinksDV.AllowUserToDeleteRows = false;
            this.invDrinksDV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.invDrinksDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.invDrinksDV.Location = new System.Drawing.Point(19, 22);
            this.invDrinksDV.Name = "invDrinksDV";
            this.invDrinksDV.ReadOnly = true;
            this.invDrinksDV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.invDrinksDV.RowTemplate.Height = 24;
            this.invDrinksDV.Size = new System.Drawing.Size(804, 619);
            this.invDrinksDV.TabIndex = 59;
            this.invDrinksDV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invDrinksDV_CellClick);
            this.invDrinksDV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invDrinksDV_CellContentClick);
            this.invDrinksDV.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.invDrinksDV_DataBindingComplete);
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel24.Controls.Add(this.posDrinks);
            this.panel24.Controls.Add(this.label14);
            this.panel24.Location = new System.Drawing.Point(835, 22);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(178, 209);
            this.panel24.TabIndex = 51;
            // 
            // posDrinks
            // 
            this.posDrinks.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("posDrinks.BackgroundImage")));
            this.posDrinks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.posDrinks.Location = new System.Drawing.Point(26, 20);
            this.posDrinks.Name = "posDrinks";
            this.posDrinks.Size = new System.Drawing.Size(130, 130);
            this.posDrinks.TabIndex = 43;
            this.posDrinks.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.DodgerBlue;
            this.label14.Font = new System.Drawing.Font("dark forest", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(-1, 150);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(137, 55);
            this.label14.TabIndex = 42;
            this.label14.Text = "DRINKS";
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.DarkOrange;
            this.panel25.Location = new System.Drawing.Point(835, 352);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(178, 289);
            this.panel25.TabIndex = 53;
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.Orange;
            this.panel26.Controls.Add(this.invButtonD);
            this.panel26.Location = new System.Drawing.Point(835, 231);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(178, 122);
            this.panel26.TabIndex = 52;
            // 
            // invButtonD
            // 
            this.invButtonD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.invButtonD.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invButtonD.ForeColor = System.Drawing.Color.White;
            this.invButtonD.Location = new System.Drawing.Point(15, 36);
            this.invButtonD.Margin = new System.Windows.Forms.Padding(0);
            this.invButtonD.Name = "invButtonD";
            this.invButtonD.Size = new System.Drawing.Size(148, 51);
            this.invButtonD.TabIndex = 61;
            this.invButtonD.Text = "Load Products";
            this.invButtonD.UseVisualStyleBackColor = true;
            this.invButtonD.Click += new System.EventHandler(this.invButtonD_Click);
            // 
            // tabFruits
            // 
            this.tabFruits.Controls.Add(this.invFruitsDV);
            this.tabFruits.Controls.Add(this.panel19);
            this.tabFruits.Controls.Add(this.panel20);
            this.tabFruits.Controls.Add(this.panel21);
            this.tabFruits.Location = new System.Drawing.Point(4, 45);
            this.tabFruits.Name = "tabFruits";
            this.tabFruits.Size = new System.Drawing.Size(1029, 658);
            this.tabFruits.TabIndex = 4;
            this.tabFruits.Text = "Fruits";
            this.tabFruits.UseVisualStyleBackColor = true;
            // 
            // invFruitsDV
            // 
            this.invFruitsDV.AllowUserToAddRows = false;
            this.invFruitsDV.AllowUserToDeleteRows = false;
            this.invFruitsDV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.invFruitsDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.invFruitsDV.Location = new System.Drawing.Point(15, 20);
            this.invFruitsDV.Name = "invFruitsDV";
            this.invFruitsDV.ReadOnly = true;
            this.invFruitsDV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToFirstHeader;
            this.invFruitsDV.RowTemplate.Height = 24;
            this.invFruitsDV.Size = new System.Drawing.Size(804, 619);
            this.invFruitsDV.TabIndex = 58;
            this.invFruitsDV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invFruitsDV_CellClick);
            this.invFruitsDV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invFruitsDV_CellContentClick);
            this.invFruitsDV.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.invFruitsDV_DataBindingComplete);
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.DarkOrange;
            this.panel19.Location = new System.Drawing.Point(830, 350);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(178, 289);
            this.panel19.TabIndex = 57;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.Orange;
            this.panel20.Controls.Add(this.invButtonF);
            this.panel20.Location = new System.Drawing.Point(830, 229);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(178, 122);
            this.panel20.TabIndex = 56;
            // 
            // invButtonF
            // 
            this.invButtonF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.invButtonF.Font = new System.Drawing.Font("Bebas Neue", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invButtonF.ForeColor = System.Drawing.Color.White;
            this.invButtonF.Location = new System.Drawing.Point(15, 36);
            this.invButtonF.Margin = new System.Windows.Forms.Padding(0);
            this.invButtonF.Name = "invButtonF";
            this.invButtonF.Size = new System.Drawing.Size(148, 51);
            this.invButtonF.TabIndex = 61;
            this.invButtonF.Text = "Load Products";
            this.invButtonF.UseVisualStyleBackColor = true;
            this.invButtonF.Click += new System.EventHandler(this.invButtonF_Click);
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel21.Controls.Add(this.label15);
            this.panel21.Controls.Add(this.posFruits);
            this.panel21.Location = new System.Drawing.Point(830, 20);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(178, 209);
            this.panel21.TabIndex = 48;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.DodgerBlue;
            this.label15.Font = new System.Drawing.Font("dark forest", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(-5, 153);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(198, 55);
            this.label15.TabIndex = 42;
            this.label15.Text = "FRUITS";
            // 
            // posFruits
            // 
            this.posFruits.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("posFruits.BackgroundImage")));
            this.posFruits.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.posFruits.Location = new System.Drawing.Point(23, 27);
            this.posFruits.Name = "posFruits";
            this.posFruits.Size = new System.Drawing.Size(130, 130);
            this.posFruits.TabIndex = 41;
            this.posFruits.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel4.Controls.Add(this.label1);
            this.panel4.Location = new System.Drawing.Point(1219, 169);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(459, 47);
            this.panel4.TabIndex = 39;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DodgerBlue;
            this.label1.Font = new System.Drawing.Font("Bebas Neue", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(258, 36);
            this.label1.TabIndex = 41;
            this.label1.Text = "ADD OR UPDATE A PRODUCT";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.pictureBox2);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.productdateTimePicker);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.productlistCategory);
            this.panel6.Controls.Add(this.productSupplierTB);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.productRetailTB);
            this.panel6.Controls.Add(this.productCostTB);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.productQuantityTB);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.productNameTB);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.button2);
            this.panel6.Controls.Add(this.button1);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.productIdTB);
            this.panel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel6.Location = new System.Drawing.Point(1219, 213);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(459, 422);
            this.panel6.TabIndex = 40;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(400, 9);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 30);
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.DodgerBlue;
            this.label9.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(17, 284);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 24);
            this.label9.TabIndex = 16;
            this.label9.Text = "Date Acquired:";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // productdateTimePicker
            // 
            this.productdateTimePicker.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productdateTimePicker.Location = new System.Drawing.Point(185, 283);
            this.productdateTimePicker.Name = "productdateTimePicker";
            this.productdateTimePicker.Size = new System.Drawing.Size(245, 28);
            this.productdateTimePicker.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label8.Location = new System.Drawing.Point(268, 201);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(132, 24);
            this.label8.TabIndex = 14;
            this.label8.Text = "Product Category:";
            // 
            // productlistCategory
            // 
            this.productlistCategory.BackColor = System.Drawing.Color.Gainsboro;
            this.productlistCategory.Font = new System.Drawing.Font("Bebas Neue", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productlistCategory.FormattingEnabled = true;
            this.productlistCategory.ItemHeight = 21;
            this.productlistCategory.Items.AddRange(new object[] {
            "Sweets",
            "Pastry",
            "Meats",
            "Drinks",
            "Fruits"});
            this.productlistCategory.Location = new System.Drawing.Point(266, 231);
            this.productlistCategory.Name = "productlistCategory";
            this.productlistCategory.Size = new System.Drawing.Size(164, 25);
            this.productlistCategory.TabIndex = 13;
            this.productlistCategory.SelectedIndexChanged += new System.EventHandler(this.productlistCategory_SelectedIndexChanged);
            // 
            // productSupplierTB
            // 
            this.productSupplierTB.BackColor = System.Drawing.Color.Gainsboro;
            this.productSupplierTB.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productSupplierTB.Location = new System.Drawing.Point(15, 228);
            this.productSupplierTB.Name = "productSupplierTB";
            this.productSupplierTB.Size = new System.Drawing.Size(245, 28);
            this.productSupplierTB.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label7.Location = new System.Drawing.Point(11, 201);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 24);
            this.label7.TabIndex = 11;
            this.label7.Text = "Product Supplier:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label6.Location = new System.Drawing.Point(228, 139);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(150, 24);
            this.label6.TabIndex = 10;
            this.label6.Text = "Product Retail Price:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // productRetailTB
            // 
            this.productRetailTB.BackColor = System.Drawing.Color.Gainsboro;
            this.productRetailTB.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productRetailTB.Location = new System.Drawing.Point(232, 166);
            this.productRetailTB.Name = "productRetailTB";
            this.productRetailTB.Size = new System.Drawing.Size(198, 28);
            this.productRetailTB.TabIndex = 9;
            // 
            // productCostTB
            // 
            this.productCostTB.BackColor = System.Drawing.Color.Gainsboro;
            this.productCostTB.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productCostTB.Location = new System.Drawing.Point(15, 166);
            this.productCostTB.Name = "productCostTB";
            this.productCostTB.Size = new System.Drawing.Size(211, 28);
            this.productCostTB.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label5.Location = new System.Drawing.Point(11, 139);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 24);
            this.label5.TabIndex = 7;
            this.label5.Text = "Product Cost:";
            // 
            // productQuantityTB
            // 
            this.productQuantityTB.BackColor = System.Drawing.Color.Gainsboro;
            this.productQuantityTB.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productQuantityTB.Location = new System.Drawing.Point(266, 102);
            this.productQuantityTB.Name = "productQuantityTB";
            this.productQuantityTB.Size = new System.Drawing.Size(164, 28);
            this.productQuantityTB.TabIndex = 6;
            this.productQuantityTB.TextChanged += new System.EventHandler(this.productQuantityTB_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label4.Location = new System.Drawing.Point(262, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 24);
            this.label4.TabIndex = 5;
            this.label4.Text = "Product Quantity:";
            // 
            // productNameTB
            // 
            this.productNameTB.BackColor = System.Drawing.Color.Gainsboro;
            this.productNameTB.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productNameTB.Location = new System.Drawing.Point(15, 102);
            this.productNameTB.Name = "productNameTB";
            this.productNameTB.Size = new System.Drawing.Size(245, 28);
            this.productNameTB.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label3.Location = new System.Drawing.Point(11, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "Product Name:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Orange;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Bebas Neue", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(229, 345);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(143, 50);
            this.button2.TabIndex = 2;
            this.button2.Text = "UPDATE";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LimeGreen;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Bebas Neue", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(68, 345);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(143, 50);
            this.button1.TabIndex = 2;
            this.button1.Text = "ADD";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label2.Location = new System.Drawing.Point(11, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(202, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Product Specific Indentifier:";
            // 
            // productIdTB
            // 
            this.productIdTB.BackColor = System.Drawing.Color.Gainsboro;
            this.productIdTB.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productIdTB.Location = new System.Drawing.Point(15, 42);
            this.productIdTB.Name = "productIdTB";
            this.productIdTB.ReadOnly = true;
            this.productIdTB.Size = new System.Drawing.Size(415, 28);
            this.productIdTB.TabIndex = 0;
            this.productIdTB.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel7.Controls.Add(this.label10);
            this.panel7.Location = new System.Drawing.Point(1219, 635);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(459, 47);
            this.panel7.TabIndex = 41;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.DodgerBlue;
            this.label10.Font = new System.Drawing.Font("Bebas Neue", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(9, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(185, 36);
            this.label10.TabIndex = 42;
            this.label10.Text = "DELETE A PRODUCT";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.label16);
            this.panel9.Controls.Add(this.textBox1);
            this.panel9.Controls.Add(this.button4);
            this.panel9.Location = new System.Drawing.Point(1219, 680);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(459, 146);
            this.panel9.TabIndex = 41;
            this.panel9.Paint += new System.Windows.Forms.PaintEventHandler(this.panel9_Paint);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Bebas Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label16.Location = new System.Drawing.Point(11, 16);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(202, 24);
            this.label16.TabIndex = 5;
            this.label16.Text = "Product Specific Indentifier:";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox1.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(15, 46);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(408, 28);
            this.textBox1.TabIndex = 4;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Red;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Bebas Neue", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(162, 84);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(143, 50);
            this.button4.TabIndex = 3;
            this.button4.Text = "DELETE";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel22.Controls.Add(this.label18);
            this.panel22.Location = new System.Drawing.Point(1219, 97);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(140, 66);
            this.panel22.TabIndex = 42;
            this.panel22.Paint += new System.Windows.Forms.PaintEventHandler(this.panel22_Paint);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.DodgerBlue;
            this.label18.Font = new System.Drawing.Font("Bebas Neue", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(3, 13);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(108, 45);
            this.label18.TabIndex = 5;
            this.label18.Text = "EXPORT";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.DodgerBlue;
            this.label17.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(14, 15);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(174, 20);
            this.label17.TabIndex = 5;
            this.label17.Text = "Export Inventory Collection";
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.White;
            this.panel23.Controls.Add(this.label19);
            this.panel23.Controls.Add(this.exportExcel);
            this.panel23.Controls.Add(this.label17);
            this.panel23.Location = new System.Drawing.Point(1352, 97);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(326, 66);
            this.panel23.TabIndex = 11;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Green;
            this.label19.Font = new System.Drawing.Font("Bebas Neue", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(14, 35);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(128, 20);
            this.label19.TabIndex = 14;
            this.label19.Text = "Into Microsoft Excel";
            // 
            // exportExcel
            // 
            this.exportExcel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("exportExcel.BackgroundImage")));
            this.exportExcel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.exportExcel.Location = new System.Drawing.Point(253, 6);
            this.exportExcel.Name = "exportExcel";
            this.exportExcel.Size = new System.Drawing.Size(64, 57);
            this.exportExcel.TabIndex = 13;
            this.exportExcel.TabStop = false;
            this.exportExcel.Click += new System.EventHandler(this.exportExcel_Click);
            // 
            // Inventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1700, 860);
            this.Controls.Add(this.panel23);
            this.Controls.Add(this.panel22);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.invTabs);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Inventory";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inventory";
            this.Load += new System.EventHandler(this.Inventory_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.posIcon)).EndInit();
            this.invTabs.ResumeLayout(false);
            this.tabSweets.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.invSweetsDV)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posSweets)).EndInit();
            this.tabPastry.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.invPastryDV)).EndInit();
            this.panel16.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posPastries)).EndInit();
            this.tabMeats.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.invMeatsDV)).EndInit();
            this.panel18.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posMeats)).EndInit();
            this.tabDrinks.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.invDrinksDV)).EndInit();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.posDrinks)).EndInit();
            this.panel26.ResumeLayout(false);
            this.tabFruits.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.invFruitsDV)).EndInit();
            this.panel20.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.posFruits)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.exportExcel)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label ScreenTitle;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox dashboardIcon;
        private System.Windows.Forms.PictureBox inventoryIcon;
        private System.Windows.Forms.PictureBox posIcon;
        private System.Windows.Forms.TabControl invTabs;
        private System.Windows.Forms.TabPage tabSweets;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button invButtonS;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox posSweets;
        private System.Windows.Forms.TabPage tabPastry;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Button invButtonP;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.PictureBox posPastries;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabPage tabMeats;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Button invButtonM;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.PictureBox posMeats;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TabPage tabDrinks;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.PictureBox posDrinks;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Button invButtonD;
        private System.Windows.Forms.TabPage tabFruits;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Button invButtonF;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox posFruits;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox productIdTB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox productNameTB;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox productRetailTB;
        private System.Windows.Forms.TextBox productCostTB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox productQuantityTB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox productlistCategory;
        private System.Windows.Forms.TextBox productSupplierTB;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker productdateTimePicker;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView invFruitsDV;
        private System.Windows.Forms.DataGridView invDrinksDV;
        private System.Windows.Forms.DataGridView invMeatsDV;
        private System.Windows.Forms.DataGridView invPastryDV;
        private System.Windows.Forms.DataGridView invSweetsDV;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox exportExcel;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}